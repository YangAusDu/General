#include <stdio.h>
#include<string.h>
#include<stdlib.h>
#include <stdbool.h>



void Elimination(int i, int j,int x, int a[i][j], int b[9][9][9]);

void eliminate_row(int i,int j,int a[i][j],int b[9][9][9]);
void eliminate_column(int i,int j,int a[i][j],int b[9][9][9]);
void eliminate_square(int i, int j, int a[9][9], int b[9][9][9]);
void eliminate_sudoku(int a[9][9], int b[9][9][9]);
void build_matrix( int b[9][9][9]);

bool check_sudoku(int a[9][9]);
bool check_row(int a[9][9]);
bool check_column(int a[9][9]);
bool check_square(int a[9][9]),
check_square1(int a[9][9]), 
check_square2(int a[9][9]), 
check_square3(int a[9][9]), 
check_square4(int a[9][9]), 
check_square5(int a[9][9]),
check_square6(int a[9][9]) , 
check_square7(int a[9][9]) , 
check_square8(int a[9][9]) , 
check_square9(int a[9][9]);

int get_square(int i, int j);
int get_value(int i, int j, int b[9][9][9]);

void change_matrix(int b[9][9][9],int possible_number[9][9][9]);
int zero_position(int a[9][9],int *i,int *j);
int recursion(int a[9][9],int b[9][9][9]);
bool check_within(int number,int i, int j,int b[9][9][9]);




//////////////////////////////

int main(int argc, char *argv[]){
    FILE *fp;
    int i,j,k,count;
    int a[9][9];
    int b[9][9][9];
    int possible_number[9][9][9]={0};
    char *outfile, solution_name[30]="solution_";
    

    if (argc != 3){
         printf("Wrong command\n");
         printf("Command line must be ./program_name -i sudoku00x.txt.\n ");
         return -1;
    }
    if (strcmp(argv[1], "-i")!= 0 ){
        printf("Command line must be ./program_name -i sudoku00x.txt.\n");
        return -2;
    }
    if ((fp = fopen(argv[2],"r")) == NULL){
         printf("Cannot find the file.\n");
         return 0;
    }
    for (i=0;i<9;i++){
        for (j=0;j<9;j++){
            fscanf(fp,"%d",&a[i][j]);
        }
    }

   // build_matrix(b);
   // eliminate_sudoku(a,b);
    change_matrix(b,possible_number);
    recursion(a,possible_number);
   
    

    


// output
    outfile = strcat(solution_name,argv[2]);

    fp = fopen(solution_name,"w");
    for (i=0;i<9;i++){
        for (k=0;k<9;k++){
            fprintf(fp,"%d ",a[i][k]);
        }
        fprintf(fp,"\n");
    }
    fclose(fp);
}

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////////////function//////////////////////////
//////////////////////////////////////////////////////
/////////////////////////////////////////////////////

int recursion(int a[9][9],int b[9][9][9]) {
	
	int row = 0;
	int col = 0;
	
	if (!zero_position(a, &row, &col)){
		return 1;
	}
	
	for (int num = 1; num <= 9; num++ ) {
		build_matrix(b);
        eliminate_sudoku(a,b);
		if (check_within(num, row, col, b)) {
           // printf("at %d %d, %d is safe\n",row,col,num);
			a[row][col] = num;
			
			if (recursion(a,b)) {
				return 1;
			}
			
			a[row][col] = 0;
		}
	}
	
	return 0;
}


bool check_within(int number,int i, int j,int b[9][9][9]){
    int k=0;
    for (k=0;k<9;k++){
        if(b[i][j][k] == number){
            return true;
        }
    }
    return false;
}

int zero_position(int a[9][9],int*i,int*j){
    for (*i=0;*i<9;(*i)++){
        for(*j=0;*j<9;(*j)++){
            if (a[*i][*j] == 0){
                return true;
            }
        }
    }
    return false;
}

void change_matrix(int b[9][9][9],int possible_number[9][9][9]){
    int i,j,k,n;
    for (i=0;i<9;i++){
        for(j=0;j<9;j++){
            n = 0;
            for (k=0;k<9;k++){
                if(b[i][j][k]!=0){
                    possible_number[i][j][n] = b[i][j][k];
                    n = n + 1;
                }
            }
        }
    }
}

void eliminate_sudoku(int a[9][9], int b[9][9][9]){
      int x,y,z;
      for(x=0;x<9;x++){
          for(y=0;y<9;y++){
            if (a[x][y]==0){
                eliminate_row(x,y,a,b);
                eliminate_column(x,y,a,b);
                eliminate_square(x,y,a,b);
            }
            else{
                for(z=0;z<9;z++){
                    b[x][y][z]=0;
                }
            }
        }
      }
}


void eliminate_row(int i,int j,int a[9][9],int b[9][9][9]){
    int k;
    for (k=0;k<9;k++){
        if (a[i][k] != 0){
            Elimination(i,j,a[i][k],a,b);
        }
    }
}

void eliminate_column(int i,int j,int a[9][9],int b[9][9][9]){
    int k;
    for (k=0;k<9;k++){
        if(a[k][j]!=0){
            Elimination(i,j,a[k][j],a,b);
        }
    }

}

int get_square(int i, int j){
    int square = 0;
    if (i>=0 && i<= 2 && j>=0 && j<= 2){
        square = 1;
    }
    else if(i>=3 && i<= 5 && j>=0 && j<= 2){
        square = 2;
    }
    else if(i>=6 && i<= 8 && j>=0 && j<= 2){
        square = 3;
    }
    else if(i>=0 && i<= 2 && j>=3 && j<= 5){
        square = 4;
    }
    else if(i>=3 && i<= 5 && j>=3 && j<= 5){
        square = 5;
    }
    else if(i>=6 && i<= 8 && j>=3 && j<= 5){
        square = 6;
    }
    else if(i>=0 && i<= 2 && j>=6 && j<= 8){       
        square = 7;
    }
    else if(i>=3 && i<= 5 && j>=6 && j<= 8){
        square = 8;
    }
    else if(i>=6 && i<= 8 && j>=6 && j<= 8){
        square = 9;
    }
    return square;
}

void eliminate_square(int i, int j, int a[9][9],int b[9][9][9]){
    int square = get_square(i,j);
    int i1, i2, j1, j2;
    int x,y;
    switch(square){
        case 1:
             i1 = 0;
             i2 = 2;
             j1 = 0;
             j2 = 2;
             break;
        case 2:
             i1 = 3;
             i2 = 5;
             j1 = 0;
             j2 = 2;
             break;
        case 3:
             i1 = 6;
             i2 = 8;
             j1 = 0;
             j2 = 2;
             break;
        case 4:
             i1 = 0;
             i2 = 2;
             j1 = 3;
             j2 = 5;
             break;
        case 5:
             i1 = 3;
             i2 = 5;
             j1 = 3;
             j2 = 5;
             break;
        case 6:
             i1 = 6;
             i2 = 8;
             j1 = 3;
             j2 = 5;
             break;
        case 7:
             i1 = 0;
             i2 = 2;
             j1 = 6;
             j2 = 8;
             break;
        case 8:
             i1 = 3;
             i2 = 5;
             j1 = 6;
             j2 = 8;
             break;
        case 9:
             i1 = 6;
             i2 = 8;
             j1 = 6;
             j2 = 8;
             break;
    }
    for (x=i1;x<= i2;x++){
        for (y=j1;y<=j2;y++){
            if (a[x][y] != 0){
                Elimination(i,j,a[x][y],a,b);
            }
        }
    }
}

void build_matrix( int b[9][9][9]){
    int i,j,k;
    for (i=0;i<9;i++){
        for (j=0;j<9;j++){
            for (k=0;k<9;k++){
                b[i][j][k]=k+1;
            }
        }
    }
}

void Elimination(int i, int j, int x, int a[i][j], int b[9][9][9]){
    int k;
    for (k=0;k<9;k++){
        if (b[i][j][k]==x){
            b[i][j][k] =0;
        }    
    }
}


int get_value(int i, int j, int b[9][9][9]){
    int k;
    int index;
    for (k=0;k<9;k++){
        if (b[i][j][k]!=0){
            index = k;
            break;
        }
    }
    return b[i][j][index];
} 

bool check_sudoku(int a[9][9]){
    bool result = false;
    if (check_row(a) && check_column(a)&& check_square(a)){
        result = true;
    }
    return result;
}

bool check_row(int a[9][9]){
  int i,j,k;
  bool result = true;

  for (i=0;i<9;i++){
      int check[9]={false};
      for (j=0;j<9;j++){
          if(a[i][j]==0){
              result = false;
          }
          else{
              check[a[i][j]-1] = true;
          }
      }
      for (k=0;k<9;k++){
          if (check[k]==0){
          result = false;
          }
      }
  }
  return result;
}

bool check_column(int a[9][9]){
  int i,j,k;
  bool result = true;
  
  for (i=0;i<9;i++){
      int check[9]={false};
      for (j=0;j<9;j++){
          if(a[j][i]==0){
              result = false;
          }
          else{
              check[a[j][i]-1] = true;
          }
      }
      for (k=0;k<9;k++){
          if (check[i]==0){
          result = false;
          }
      }
  }
  return result;
}

bool check_square(int a[9][9]){
  bool result=false;

  if( check_square1(a) && 
      check_square2(a) && 
      check_square3(a) && 
      check_square4(a) && 
      check_square5(a)&& 
      check_square6(a) && 
      check_square7(a) && 
      check_square8(a) && 
      check_square9(a) == true ){
      result = true;
  }
  return result;
}

bool check_square1(int a[9][9]){
  bool result = true;
  int i,j,k;
  int check[9] = {false};
  for (i=0;i<=2;i++){
      for (j=0;j<=2;j++){
          if(a[j][i]==0){
              result = false;
          }
          else{
              check[a[j][i]-1] = true;
          }
      }    
  } 
  for (k=0;k<9;k++){
      if(check[k]==false){
          result = false;
      }
  }
  return result;
}

bool check_square2(int a[9][9]){
  bool result = true;
  int i,j,k;
  int check[9] = {false};
  for (i=0;i<=2;i++){
      for (j=3;j<=5;j++){
          if(a[j][i]==0){
              result = false;
          }
          else{
              check[a[j][i]-1] = true;
          }
      }    
  } 
  for (k=0;k<9;k++){
      if(check[k]==false){
          result = false;
      }
  }
  return result;
}

bool check_square3(int a[9][9]){
  bool result = true;
  int i,j,k;
  int check[9] = {false};
  for (i=0;i<=2;i++){
      for (j=6;j<=8;j++){
          if(a[j][i]==0){
              result = false;
          }
          else{
              check[a[j][i]-1] = true;
          }
      }    
  } 
  for (k=0;k<9;k++){
      if(check[k]==false){
          result = false;
      }
  }
  return result;
}

bool check_square4(int a[9][9]){
  bool result = true;
  int i,j,k;
  int check[9] = {false};
  for (i=3;i<=5;i++){
      for (j=0;j<=2;j++){
          if(a[j][i]==0){
              result = false;
          }
          else{
              check[a[j][i]-1] = true;
          }
      }    
  } 
  for (k=0;k<9;k++){
      if(check[k]==false){
          result = false;
      }
  }
  return result;
}

bool check_square5(int a[9][9]){
  bool result = true;
  int i,j,k;
  int check[9] = {false};
  for (i=3;i<=5;i++){
      for (j=3;j<=5;j++){
          if(a[j][i]==0){
              result = false;
          }
          else{
              check[a[j][i]-1] = true;
          }
      }    
  } 
  for (k=0;k<9;k++){
      if(check[k]==false){
          result = false;
      }
  }
  return result;
}

bool check_square6(int a[9][9]){
  bool result = true;
  int i,j,k;
  int check[9] = {false};
  for (i=3;i<=5;i++){
      for (j=6;j<=8;j++){
          if(a[j][i]==0){
              result = false;
          }
          else{
              check[a[j][i]-1] = true;
          }
      }    
  } 
  for (k=0;k<9;k++){
      if(check[k]==false){
          result = false;
      }
  }
  return result;
}

bool check_square7(int a[9][9]){
  bool result = true;
  int i,j,k;
  int check[9] = {false};
  for (i=6;i<=8;i++){
      for (j=0;j<=2;j++){
          if(a[j][i]==0){
              result = false;
          }
          else{
              check[a[j][i]-1] = true;
          }
      }    
  } 
  for (k=0;k<9;k++){
      if(check[k]==false){
          result = false;
      }
  }
  return result;
}

bool check_square8(int a[9][9]){
  bool result = true;
  int i,j,k;
  int check[9] = {false};
  for (i=6;i<=8;i++){
      for (j=3;j<=5;j++){
          if(a[j][i]==0){
              result = false;
          }
          else{
              check[a[j][i]-1] = true;
          }
      }    
  } 
  for (k=0;k<9;k++){
      if(check[k]==false){
          result = false;
      }
  }
  return result;
}

bool check_square9(int a[9][9]){
  bool result = true;
  int i,j,k;
  int check[9] = {false};
  for (i=6;i<=8;i++){
      for (j=6;j<=8;j++){
          if(a[j][i]==0){
              result = false;
          }
          else{
              check[a[j][i]-1] = true;
          }
      }    
  } 
  for (k=0;k<9;k++){
      if(check[k]==false){
          result = false;
      }
  }
  return result;
}
